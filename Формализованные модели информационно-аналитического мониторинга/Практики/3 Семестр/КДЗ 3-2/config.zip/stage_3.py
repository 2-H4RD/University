from __future__ import annotations

from typing import List, Sequence, Tuple
import random

import config as cfg
import stage_1 as st1


TOURNAMENT_SIZE = cfg.TOURNAMENT_SIZE
MUTATION_PROBABILITY = cfg.MUTATION_PROBABILITY


# ------------------------------------------------------------
# ТУРНИРНАЯ СЕЛЕКЦИЯ
# ------------------------------------------------------------
def tournament_select_one(
    population: Sequence[st1.Individual],
    fitness_list: Sequence[float],
    tournament_size: int = TOURNAMENT_SIZE,
) -> st1.Individual:
    if not population:
        raise ValueError("Популяция пуста")
    if len(population) != len(fitness_list):
        raise ValueError("Размер population и fitness_list должен совпадать")
    if tournament_size <= 0:
        raise ValueError("tournament_size должен быть > 0")

    selected_indices = [random.randrange(len(population)) for _ in range(tournament_size)]
    winner_index = selected_indices[0]

    for index in selected_indices[1:]:
        if fitness_list[index] > fitness_list[winner_index]:
            winner_index = index

    return st1.clone_individual(population[winner_index])


def build_parent_population(
    population: Sequence[st1.Individual],
    fitness_list: Sequence[float],
    target_size: int,
    tournament_size: int = TOURNAMENT_SIZE,
) -> List[st1.Individual]:
    if target_size <= 0:
        raise ValueError("target_size должен быть > 0")
    parents = []
    for _ in range(target_size):
        parents.append(
            tournament_select_one(
                population=population,
                fitness_list=fitness_list,
                tournament_size=tournament_size,
            )
        )
    return parents


# ------------------------------------------------------------
# ТРЁХТОЧЕЧНЫЙ КРОССОВЕР
# ------------------------------------------------------------
def generate_crossover_points_for_pair(individual: st1.Individual) -> Tuple[int, int, int]:
    if individual.genotype_length < 4:
        raise ValueError("Хромосома слишком короткая для трёхточечного кроссовера")

    point2 = individual.split_point
    if point2 <= 1 or point2 >= individual.genotype_length - 1:
        raise ValueError("Невозможно выбрать корректные точки кроссовера")

    point1 = random.randint(1, point2 - 1)
    point3 = random.randint(point2 + 1, individual.genotype_length - 1)
    return point1, point2, point3


def three_point_crossover(
    parent1: st1.Individual,
    parent2: st1.Individual,
    point1: int,
    point2: int,
    point3: int,
) -> Tuple[List[int], List[int]]:
    if parent1.genotype_length != parent2.genotype_length:
        raise ValueError("Длины хромосом родителей не совпадают")
    if not (1 <= point1 < point2 < point3 < parent1.genotype_length):
        raise ValueError("Некорректные точки кроссовера")

    g1 = parent1.genotype
    g2 = parent2.genotype

    child1 = g2[:point1] + g1[point1:point2] + g2[point2:point3] + g1[point3:]
    child2 = g1[:point1] + g2[point1:point2] + g1[point2:point3] + g2[point3:]
    return child1, child2


# ------------------------------------------------------------
# МУТАЦИЯ
# ------------------------------------------------------------
def mutate_genotype(
    genotype: Sequence[int],
    mutation_probability: float = MUTATION_PROBABILITY,
) -> List[int]:
    if not (0.0 <= mutation_probability <= 1.0):
        raise ValueError("mutation_probability должен быть в диапазоне [0, 1]")

    mutated = list(genotype)
    if random.random() < mutation_probability:
        bit_index = random.randrange(len(mutated))
        mutated[bit_index] = 1 - mutated[bit_index]
    return mutated


# ------------------------------------------------------------
# ФОРМИРОВАНИЕ ПОТОМКОВ
# ------------------------------------------------------------
def build_offspring_population(
    parent_population: Sequence[st1.Individual],
    mutation_probability: float = MUTATION_PROBABILITY,
) -> List[st1.Individual]:
    if not parent_population:
        raise ValueError("Популяция родителей пуста")
    if len(parent_population) % 2 != 0:
        raise ValueError("Размер parent_population должен быть чётным")

    shuffled_parents = list(parent_population)
    random.shuffle(shuffled_parents)

    offspring: List[st1.Individual] = []
    for i in range(0, len(shuffled_parents), 2):
        parent1 = shuffled_parents[i]
        parent2 = shuffled_parents[i + 1]

        point1, point2, point3 = generate_crossover_points_for_pair(parent1)
        child1_bits, child2_bits = three_point_crossover(parent1, parent2, point1, point2, point3)

        child1_bits = mutate_genotype(child1_bits, mutation_probability=mutation_probability)
        child2_bits = mutate_genotype(child2_bits, mutation_probability=mutation_probability)

        child1 = st1.Individual(
            genotype=child1_bits,
            bits_per_gene=parent1.bits_per_gene,
            genes_per_player_a=parent1.genes_per_player_a,
            genes_per_player_b=parent1.genes_per_player_b,
        )
        child2 = st1.Individual(
            genotype=child2_bits,
            bits_per_gene=parent2.bits_per_gene,
            genes_per_player_a=parent2.genes_per_player_a,
            genes_per_player_b=parent2.genes_per_player_b,
        )

        offspring.append(child1)
        offspring.append(child2)

    return offspring
