from __future__ import annotations

from typing import Dict, Iterable, List, Sequence, Tuple
import math
import random

import config as cfg
import stage_1 as st1


A_MATRIX = cfg.A_PAYOFF_MATRIX
B_MATRIX = cfg.B_PAYOFF_MATRIX
PSI = cfg.PSI
ARCHIVE_ROUND_DIGITS = cfg.ARCHIVE_ROUND_DIGITS


# ------------------------------------------------------------
# ВЫЧИСЛЕНИЕ ВЫИГРЫШЕЙ В БИМАТРИЧНОЙ ИГРЕ
# ------------------------------------------------------------
def payoff_a(strategy_a: Sequence[float], strategy_b: Sequence[float]) -> float:
    value = 0.0
    for i, p_i in enumerate(strategy_a):
        for j, q_j in enumerate(strategy_b):
            value += p_i * A_MATRIX[i][j] * q_j
    return value


def payoff_b(strategy_a: Sequence[float], strategy_b: Sequence[float]) -> float:
    value = 0.0
    for i, p_i in enumerate(strategy_a):
        for j, q_j in enumerate(strategy_b):
            value += p_i * B_MATRIX[i][j] * q_j
    return value


def decode_and_evaluate(individual: st1.Individual) -> Tuple[List[float], List[float], float, float]:
    strategy_a, strategy_b = st1.decode_individual_to_strategy_profile(individual)
    u_a = payoff_a(strategy_a, strategy_b)
    u_b = payoff_b(strategy_a, strategy_b)
    return strategy_a, strategy_b, u_a, u_b


def build_payoff_pairs(population: Sequence[st1.Individual]) -> List[Tuple[float, float]]:
    pairs: List[Tuple[float, float]] = []
    for individual in population:
        _, _, u_a, u_b = decode_and_evaluate(individual)
        pairs.append((u_a, u_b))
    return pairs


# ------------------------------------------------------------
# ВИЗУАЛИЗАЦИОННЫЕ ДАННЫЕ
# ------------------------------------------------------------
def _rounded_point(point: Tuple[float, float], round_digits: int = ARCHIVE_ROUND_DIGITS) -> Tuple[float, float]:
    return (round(point[0], round_digits), round(point[1], round_digits))


def unique_points(
    points: Iterable[Tuple[float, float]],
    round_digits: int = ARCHIVE_ROUND_DIGITS,
) -> List[Tuple[float, float]]:
    unique_map: Dict[Tuple[float, float], Tuple[float, float]] = {}
    for point in points:
        unique_map[_rounded_point(point, round_digits=round_digits)] = (float(point[0]), float(point[1]))
    return list(unique_map.values())


def generate_random_strategy_on_simplex(dim: int) -> List[float]:
    if dim <= 0:
        raise ValueError("dim должен быть > 0")

    raw = [random.gammavariate(1.0, 1.0) for _ in range(dim)]
    total = sum(raw)
    if total <= 0.0:
        uniform = 1.0 / dim
        return [uniform for _ in range(dim)]
    return [value / total for value in raw]




def _integer_compositions(total: int, parts: int):
    if parts <= 0:
        return
    if parts == 1:
        yield (total,)
        return
    for value in range(total + 1):
        for tail in _integer_compositions(total - value, parts - 1):
            yield (value,) + tail


def generate_simplex_grid(dim: int, subdivisions: int) -> List[List[float]]:
    if dim <= 0:
        raise ValueError("dim должен быть > 0")
    if subdivisions <= 0:
        raise ValueError("subdivisions должен быть > 0")

    return [
        [part / subdivisions for part in composition]
        for composition in _integer_compositions(subdivisions, dim)
    ]


def build_attainable_payoff_cloud_grid(
    subdivisions_a: int = 20,
    subdivisions_b: int = 20,
    include_pure_points: bool = True,
    round_digits: int = ARCHIVE_ROUND_DIGITS,
) -> List[Tuple[float, float]]:
    strategies_a = generate_simplex_grid(cfg.ROWS_COUNT, subdivisions_a)
    strategies_b = generate_simplex_grid(cfg.COLS_COUNT, subdivisions_b)

    points: List[Tuple[float, float]] = []
    for strategy_a in strategies_a:
        for strategy_b in strategies_b:
            points.append((payoff_a(strategy_a, strategy_b), payoff_b(strategy_a, strategy_b)))

    if include_pure_points:
        points.extend(point["payoff"] for point in get_pure_payoff_points())

    return unique_points(points, round_digits=round_digits)
def build_attainable_payoff_cloud(
    sample_count: int = 12000,
    include_pure_points: bool = True,
    round_digits: int = ARCHIVE_ROUND_DIGITS,
) -> List[Tuple[float, float]]:
    if sample_count <= 0:
        raise ValueError("sample_count должен быть > 0")

    points: List[Tuple[float, float]] = []
    for _ in range(sample_count):
        strategy_a = generate_random_strategy_on_simplex(cfg.ROWS_COUNT)
        strategy_b = generate_random_strategy_on_simplex(cfg.COLS_COUNT)
        points.append((payoff_a(strategy_a, strategy_b), payoff_b(strategy_a, strategy_b)))

    if include_pure_points:
        points.extend(point["payoff"] for point in get_pure_payoff_points())

    return unique_points(points, round_digits=round_digits)


def get_pure_payoff_points() -> List[dict]:
    points: List[dict] = []
    for i in range(cfg.ROWS_COUNT):
        for j in range(cfg.COLS_COUNT):
            points.append(
                {
                    "row": i,
                    "col": j,
                    "label": f"(A{i + 1}, B{j + 1})",
                    "payoff": (float(A_MATRIX[i][j]), float(B_MATRIX[i][j])),
                }
            )
    return points


def extract_pareto_front(
    points: Sequence[Tuple[float, float]],
    round_digits: int = ARCHIVE_ROUND_DIGITS,
) -> List[Tuple[float, float]]:
    unique = unique_points(points, round_digits=round_digits)
    pareto_front: List[Tuple[float, float]] = []

    for i, point_i in enumerate(unique):
        dominated = False
        for j, point_j in enumerate(unique):
            if i == j:
                continue
            if dominates_max(point_j, point_i):
                dominated = True
                break
        if not dominated:
            pareto_front.append(point_i)

    pareto_front.sort(key=lambda point: (point[0], point[1]))
    return pareto_front


# ------------------------------------------------------------
# ПАРЕТО-ДОМИНИРОВАНИЕ ДЛЯ МАКСИМИЗАЦИИ
# ------------------------------------------------------------
def dominates_max(point_p: Tuple[float, float], point_q: Tuple[float, float]) -> bool:
    return (point_p[0] >= point_q[0] and point_p[1] >= point_q[1]) and (
        point_p[0] > point_q[0] or point_p[1] > point_q[1]
    )


def count_dominators_2d_max(payoff_pairs: Sequence[Tuple[float, float]]) -> List[int]:
    n = len(payoff_pairs)
    counts = [0] * n
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            if dominates_max(payoff_pairs[j], payoff_pairs[i]):
                counts[i] += 1
    return counts


def phi_from_dominator_counts(dominator_counts: Sequence[int], psi: float = PSI) -> List[float]:
    n = len(dominator_counts)
    if n == 0:
        return []
    if n == 1:
        return [1.0]
    if psi < 0:
        raise ValueError("psi должен быть >= 0")

    denom = n - 1
    phi_list: List[float] = []
    for b_i in dominator_counts:
        base = 1.0 + (b_i / denom)
        phi = 1.0 if psi == 0 else 1.0 / (base ** psi)
        phi_list.append(phi)
    return phi_list


def rank_population_pareto(
    population: Sequence[st1.Individual],
    psi: float = PSI,
) -> Tuple[List[Tuple[float, float]], List[int], List[float], List[int]]:
    payoff_pairs = build_payoff_pairs(population)
    dominator_counts = count_dominators_2d_max(payoff_pairs)
    phi_list = phi_from_dominator_counts(dominator_counts, psi=psi)

    elite_idx: List[int] = []
    for index, phi in enumerate(phi_list):
        if math.isclose(phi, 1.0, rel_tol=0.0, abs_tol=1e-12):
            elite_idx.append(index)

    return payoff_pairs, dominator_counts, phi_list, elite_idx


# ------------------------------------------------------------
# STATUS QUO: ГАРАНТИРОВАННЫЕ ВЫИГРЫШИ ИГРОКОВ
# ------------------------------------------------------------
def security_level_a(strategy_a: Sequence[float]) -> float:
    values_by_columns: List[float] = []
    for j in range(cfg.COLS_COUNT):
        expected_value = 0.0
        for i, p_i in enumerate(strategy_a):
            expected_value += p_i * A_MATRIX[i][j]
        values_by_columns.append(expected_value)
    return min(values_by_columns)


def security_level_b(strategy_b: Sequence[float]) -> float:
    values_by_rows: List[float] = []
    for i in range(cfg.ROWS_COUNT):
        expected_value = 0.0
        for j, q_j in enumerate(strategy_b):
            expected_value += q_j * B_MATRIX[i][j]
        values_by_rows.append(expected_value)
    return min(values_by_rows)


def evaluate_population_status_quo_a(population: Sequence[st1.Individual]) -> List[float]:
    values: List[float] = []
    for individual in population:
        strategy_a = st1.decode_individual_to_player_a_strategy(individual)
        values.append(security_level_a(strategy_a))
    return values


def evaluate_population_status_quo_b(population: Sequence[st1.Individual]) -> List[float]:
    values: List[float] = []
    for individual in population:
        strategy_b = st1.decode_individual_to_player_b_strategy(individual)
        values.append(security_level_b(strategy_b))
    return values


# ------------------------------------------------------------
# АРБИТРАЖНАЯ СХЕМА НЭША
# ------------------------------------------------------------
def nash_product(payoff_pair: Tuple[float, float], status_quo: Tuple[float, float]) -> float:
    u_a, u_b = payoff_pair
    d_a, d_b = status_quo
    if u_a < d_a or u_b < d_b:
        return -1.0
    return (u_a - d_a) * (u_b - d_b)


def evaluate_population_nash(
    population: Sequence[st1.Individual],
    status_quo: Tuple[float, float],
) -> List[float]:
    values: List[float] = []
    for individual in population:
        _, _, u_a, u_b = decode_and_evaluate(individual)
        values.append(nash_product((u_a, u_b), status_quo))
    return values


def select_best_nash_from_population(
    population: Sequence[st1.Individual],
    status_quo: Tuple[float, float],
) -> Tuple[st1.Individual, Tuple[float, float], float]:
    if not population:
        raise ValueError("Популяция пуста")

    best_index = 0
    best_pair = (-float("inf"), -float("inf"))
    best_product = -float("inf")

    for index, individual in enumerate(population):
        _, _, u_a, u_b = decode_and_evaluate(individual)
        product = nash_product((u_a, u_b), status_quo)
        if product > best_product:
            best_index = index
            best_pair = (u_a, u_b)
            best_product = product

    return st1.clone_individual(population[best_index]), best_pair, best_product


# ------------------------------------------------------------
# АРХИВ ПАРЕТО
# ------------------------------------------------------------
def _archive_key(individual: st1.Individual) -> Tuple[float, ...]:
    strategy_a, strategy_b = st1.decode_individual_to_strategy_profile(individual)
    _, _, u_a, u_b = decode_and_evaluate(individual)
    rounded = tuple(round(value, ARCHIVE_ROUND_DIGITS) for value in (u_a, u_b, *strategy_a, *strategy_b))
    return rounded


def merge_and_prune_pareto_archive(
    archive: Sequence[st1.Individual],
    candidates: Sequence[st1.Individual],
    psi: float = PSI,
) -> List[st1.Individual]:
    merged: List[st1.Individual] = st1.clone_population(archive) + st1.clone_population(candidates)
    if not merged:
        return []

    unique_map = {}
    for individual in merged:
        unique_map[_archive_key(individual)] = individual
    unique_population = list(unique_map.values())

    _, _, _, elite_idx = rank_population_pareto(unique_population, psi=psi)
    return [st1.clone_individual(unique_population[index]) for index in elite_idx]


def sort_population_by_fitness_desc(
    population: Sequence[st1.Individual],
    fitness_list: Sequence[float],
) -> List[st1.Individual]:
    if len(population) != len(fitness_list):
        raise ValueError("Длины population и fitness_list должны совпадать")
    indices = list(range(len(population)))
    indices.sort(key=lambda i: fitness_list[i], reverse=True)
    return [st1.clone_individual(population[i]) for i in indices]
