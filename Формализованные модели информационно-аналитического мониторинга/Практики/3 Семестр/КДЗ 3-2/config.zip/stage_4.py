from __future__ import annotations

from typing import Callable, Dict, List, Sequence, Tuple
import random

import config as cfg
import stage_1 as st1
import stage_2 as st2
import stage_3 as st3


POP_SIZE = cfg.POP_SIZE
MAX_GENERATIONS = cfg.MAX_GENERATIONS
STAGNATION_LIMIT = cfg.STAGNATION_LIMIT
ELITE_KEEP_COUNT = cfg.ELITE_KEEP_COUNT
TOURNAMENT_SIZE = cfg.TOURNAMENT_SIZE
MUTATION_PROBABILITY = cfg.MUTATION_PROBABILITY
PSI = cfg.PSI


# ------------------------------------------------------------
# ОБЩИЕ ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
# ------------------------------------------------------------
def initialize_random_seed(seed: int | None = cfg.RANDOM_SEED) -> None:
    if seed is not None:
        random.seed(seed)


def top_indices_by_fitness(fitness_list: Sequence[float], count: int) -> List[int]:
    if count <= 0:
        return []
    count = min(count, len(fitness_list))
    indices = list(range(len(fitness_list)))
    indices.sort(key=lambda i: fitness_list[i], reverse=True)
    return indices[:count]


def preserve_elite_individuals(population: Sequence[st1.Individual], fitness_list: Sequence[float], count: int) -> List[st1.Individual]:
    indices = top_indices_by_fitness(fitness_list, count)
    return [st1.clone_individual(population[i]) for i in indices]


def compose_next_population(
    current_population: Sequence[st1.Individual],
    fitness_list: Sequence[float],
    mutation_probability: float,
    elite_keep_count: int = ELITE_KEEP_COUNT,
    tournament_size: int = TOURNAMENT_SIZE,
) -> List[st1.Individual]:
    elite = preserve_elite_individuals(current_population, fitness_list, elite_keep_count)

    offspring_target_size = len(current_population) - len(elite)
    if offspring_target_size <= 0:
        return st1.clone_population(elite)
    if offspring_target_size % 2 != 0:
        offspring_target_size += 1

    parent_population = st3.build_parent_population(
        population=current_population,
        fitness_list=fitness_list,
        target_size=offspring_target_size,
        tournament_size=tournament_size,
    )
    offspring = st3.build_offspring_population(
        parent_population=parent_population,
        mutation_probability=mutation_probability,
    )

    next_population = elite + offspring[: len(current_population) - len(elite)]
    return next_population


def run_scalar_ga(
    evaluation_fn: Callable[[Sequence[st1.Individual]], List[float]],
    pop_size: int = POP_SIZE,
    max_generations: int = MAX_GENERATIONS,
    stagnation_limit: int = STAGNATION_LIMIT,
    elite_keep_count: int = ELITE_KEEP_COUNT,
    tournament_size: int = TOURNAMENT_SIZE,
    mutation_probability: float = MUTATION_PROBABILITY,
) -> Dict[str, object]:
    population = st1.generate_initial_population(pop_size=pop_size)

    history: List[dict] = []
    best_individual: st1.Individual | None = None
    best_fitness = -float("inf")
    best_generation = 0
    generations_without_improvement = 0

    for generation in range(1, max_generations + 1):
        fitness_list = evaluation_fn(population)
        current_best_index = max(range(len(population)), key=lambda i: fitness_list[i])
        current_best_fitness = fitness_list[current_best_index]

        if current_best_fitness > best_fitness:
            best_fitness = current_best_fitness
            best_individual = st1.clone_individual(population[current_best_index])
            best_generation = generation
            generations_without_improvement = 0
        else:
            generations_without_improvement += 1

        history.append(
            {
                "generation": generation,
                "best_fitness": current_best_fitness,
                "global_best_fitness": best_fitness,
            }
        )

        if generations_without_improvement >= stagnation_limit:
            break

        population = compose_next_population(
            current_population=population,
            fitness_list=fitness_list,
            mutation_probability=mutation_probability,
            elite_keep_count=elite_keep_count,
            tournament_size=tournament_size,
        )

    if best_individual is None:
        raise RuntimeError("ГА завершился без лучшей найденной особи")

    return {
        "best_individual": best_individual,
        "best_fitness": best_fitness,
        "best_generation": best_generation,
        "history": history,
    }


# ------------------------------------------------------------
# ЗАДАЧА 1: ПАРЕТО-ОПТИМАЛЬНЫЕ РЕШЕНИЯ
# ------------------------------------------------------------
def run_pareto_ga(
    pop_size: int = POP_SIZE,
    max_generations: int = MAX_GENERATIONS,
    elite_keep_count: int = ELITE_KEEP_COUNT,
    tournament_size: int = TOURNAMENT_SIZE,
    mutation_probability: float = MUTATION_PROBABILITY,
    psi: float = PSI,
) -> Dict[str, object]:
    population = st1.generate_initial_population(pop_size=pop_size)
    archive: List[st1.Individual] = []
    history: List[dict] = []

    best_archive_size = 0
    generations_without_improvement = 0

    for generation in range(1, max_generations + 1):
        payoff_pairs, dominator_counts, phi_list, elite_idx = st2.rank_population_pareto(population, psi=psi)
        current_elites = [population[index] for index in elite_idx]
        archive = st2.merge_and_prune_pareto_archive(archive, current_elites, psi=psi)

        archive_size = len(archive)
        best_phi = max(phi_list) if phi_list else 0.0
        history.append(
            {
                "generation": generation,
                "elite_count": len(elite_idx),
                "archive_size": archive_size,
                "best_phi": best_phi,
            }
        )

        if archive_size > best_archive_size:
            best_archive_size = archive_size
            generations_without_improvement = 0
        else:
            generations_without_improvement += 1

        if generations_without_improvement >= STAGNATION_LIMIT:
            break

        population = compose_next_population(
            current_population=population,
            fitness_list=phi_list,
            mutation_probability=mutation_probability,
            elite_keep_count=elite_keep_count,
            tournament_size=tournament_size,
        )

    archive_payoffs = st2.build_payoff_pairs(archive)
    archive_strategies = [st1.decode_individual_to_strategy_profile(individual) for individual in archive]

    return {
        "final_population": population,
        "pareto_archive": archive,
        "pareto_payoffs": archive_payoffs,
        "pareto_strategies": archive_strategies,
        "history": history,
    }


# ------------------------------------------------------------
# ЗАДАЧА 2: STATUS QUO
# ------------------------------------------------------------
def run_status_quo_ga_for_player_a(
    pop_size: int = POP_SIZE,
    max_generations: int = MAX_GENERATIONS,
) -> Dict[str, object]:
    result = run_scalar_ga(
        evaluation_fn=st2.evaluate_population_status_quo_a,
        pop_size=pop_size,
        max_generations=max_generations,
    )
    best_individual = result["best_individual"]
    strategy_a = st1.decode_individual_to_player_a_strategy(best_individual)
    value = st2.security_level_a(strategy_a)
    result.update({"strategy_a": strategy_a, "value": value})
    return result


def run_status_quo_ga_for_player_b(
    pop_size: int = POP_SIZE,
    max_generations: int = MAX_GENERATIONS,
) -> Dict[str, object]:
    result = run_scalar_ga(
        evaluation_fn=st2.evaluate_population_status_quo_b,
        pop_size=pop_size,
        max_generations=max_generations,
    )
    best_individual = result["best_individual"]
    strategy_b = st1.decode_individual_to_player_b_strategy(best_individual)
    value = st2.security_level_b(strategy_b)
    result.update({"strategy_b": strategy_b, "value": value})
    return result


def run_status_quo_ga(
    pop_size: int = POP_SIZE,
    max_generations: int = MAX_GENERATIONS,
) -> Dict[str, object]:
    result_a = run_status_quo_ga_for_player_a(pop_size=pop_size, max_generations=max_generations)
    result_b = run_status_quo_ga_for_player_b(pop_size=pop_size, max_generations=max_generations)
    status_quo = (result_a["value"], result_b["value"])
    return {
        "player_a": result_a,
        "player_b": result_b,
        "status_quo": status_quo,
    }


# ------------------------------------------------------------
# ЗАДАЧА 3: АРБИТРАЖНАЯ СХЕМА НЭША
# ------------------------------------------------------------
def run_nash_arbitration_ga(
    status_quo: Tuple[float, float],
    pop_size: int = POP_SIZE,
    max_generations: int = MAX_GENERATIONS,
) -> Dict[str, object]:
    def evaluation_fn(population: Sequence[st1.Individual]) -> List[float]:
        return st2.evaluate_population_nash(population, status_quo=status_quo)

    result = run_scalar_ga(
        evaluation_fn=evaluation_fn,
        pop_size=pop_size,
        max_generations=max_generations,
    )

    best_individual = result["best_individual"]
    strategy_a, strategy_b, u_a, u_b = st2.decode_and_evaluate(best_individual)
    result.update(
        {
            "strategy_a": strategy_a,
            "strategy_b": strategy_b,
            "payoff_pair": (u_a, u_b),
            "nash_product": st2.nash_product((u_a, u_b), status_quo),
        }
    )
    return result
