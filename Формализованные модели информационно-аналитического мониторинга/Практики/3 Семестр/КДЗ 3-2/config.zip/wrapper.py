from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple

import config as cfg
import stage_1 as st1
import stage_2 as st2
import stage_4 as st4


DEFAULT_CLOUD_SAMPLE_COUNT = getattr(cfg, "PLOT_CLOUD_SAMPLE_COUNT", 15000)
DEFAULT_SIMPLEX_GRID_SUBDIVISIONS = getattr(cfg, "PLOT_SIMPLEX_GRID_SUBDIVISIONS", 20)
DEFAULT_OUTPUT_FILENAME = getattr(cfg, "PLOT_OUTPUT_FILENAME", "bimatrix_summary_plot.png")
DEFAULT_FIGURE_SIZE = getattr(cfg, "PLOT_FIGURE_SIZE", (11, 8))
DEFAULT_SHOW_PLOT_WINDOW = getattr(cfg, "SHOW_PLOT_WINDOW", True)


# ------------------------------------------------------------
# ОБЁРТКА ДЛЯ ПОЛНОГО РЕШЕНИЯ ЗАДАНИЯ
# ------------------------------------------------------------
def solve_bimatrix_game() -> Dict[str, object]:
    st4.initialize_random_seed()

    pareto_result = st4.run_pareto_ga()
    status_quo_result = st4.run_status_quo_ga()
    status_quo = status_quo_result["status_quo"]
    nash_result = st4.run_nash_arbitration_ga(status_quo=status_quo)

    pareto_archive = pareto_result["pareto_archive"]
    if pareto_archive:
        archive_best_individual, archive_best_pair, archive_best_product = st2.select_best_nash_from_population(
            pareto_archive,
            status_quo=status_quo,
        )
        archive_best_strategy_a, archive_best_strategy_b = st1.decode_individual_to_strategy_profile(archive_best_individual)
        pareto_best_for_nash = {
            "strategy_a": archive_best_strategy_a,
            "strategy_b": archive_best_strategy_b,
            "payoff_pair": archive_best_pair,
            "nash_product": archive_best_product,
        }
    else:
        pareto_best_for_nash = None

    return {
        "pareto": pareto_result,
        "status_quo": status_quo_result,
        "nash": nash_result,
        "pareto_best_for_nash": pareto_best_for_nash,
    }


# ------------------------------------------------------------
# ПОДГОТОВКА ДАННЫХ ДЛЯ ГРАФИКА
# ------------------------------------------------------------
def build_visualization_data(
    result: Dict[str, object],
    cloud_sample_count: int = DEFAULT_CLOUD_SAMPLE_COUNT,
    simplex_grid_subdivisions: int = DEFAULT_SIMPLEX_GRID_SUBDIVISIONS,
) -> Dict[str, object]:
    if simplex_grid_subdivisions > 0:
        attainable_points = st2.build_attainable_payoff_cloud_grid(
            subdivisions_a=simplex_grid_subdivisions,
            subdivisions_b=simplex_grid_subdivisions,
        )
    else:
        attainable_points = st2.build_attainable_payoff_cloud(sample_count=cloud_sample_count)
    pareto_front = st2.extract_pareto_front(attainable_points)
    pure_points = st2.get_pure_payoff_points()

    ga_archive_payoffs = result["pareto"]["pareto_payoffs"]
    ga_archive_front = st2.extract_pareto_front(ga_archive_payoffs)

    return {
        "attainable_points": attainable_points,
        "pure_points": pure_points,
        "pareto_front": pareto_front,
        "ga_archive_front": ga_archive_front,
        "status_quo": result["status_quo"]["status_quo"],
        "nash_payoff": result["nash"]["payoff_pair"],
        "nash_product": result["nash"]["nash_product"],
    }


# ------------------------------------------------------------
# ПОСТРОЕНИЕ И СОХРАНЕНИЕ ГРАФИКА
# ------------------------------------------------------------
def plot_bimatrix_summary(
    plot_data: Dict[str, object],
    output_path: str | Path = DEFAULT_OUTPUT_FILENAME,
    show_window: bool = DEFAULT_SHOW_PLOT_WINDOW,
) -> Path:
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError(
            "Для построения графика требуется matplotlib. Установите пакет командой: pip install matplotlib"
        ) from exc

    output_path = Path(output_path)

    attainable_points: List[Tuple[float, float]] = plot_data["attainable_points"]
    pure_points = plot_data["pure_points"]
    pareto_front: List[Tuple[float, float]] = plot_data["pareto_front"]
    ga_archive_front: List[Tuple[float, float]] = plot_data["ga_archive_front"]
    status_quo = plot_data["status_quo"]
    nash_payoff = plot_data["nash_payoff"]
    nash_product = plot_data["nash_product"]

    fig, ax = plt.subplots(figsize=DEFAULT_FIGURE_SIZE)

    if attainable_points:
        cloud_x = [point[0] for point in attainable_points]
        cloud_y = [point[1] for point in attainable_points]
        ax.scatter(
            cloud_x,
            cloud_y,
            s=12,
            alpha=0.18,
            marker="o",
            color="tab:blue",
            label="Множество достижимых выплат",
            zorder=1,
        )

    if pareto_front:
        pareto_x = [point[0] for point in pareto_front]
        pareto_y = [point[1] for point in pareto_front]
        ax.plot(
            pareto_x,
            pareto_y,
            color="green",
            linewidth=2.8,
            alpha=0.9,
            zorder=3,
        )
        ax.scatter(
            pareto_x,
            pareto_y,
            s=34,
            color="green",
            label="Множество Парето-оптимальных решений",
            zorder=4,
        )

    if ga_archive_front:
        archive_x = [point[0] for point in ga_archive_front]
        archive_y = [point[1] for point in ga_archive_front]
        ax.scatter(
            archive_x,
            archive_y,
            s=28,
            marker="o",
            color="darkgreen",
            alpha=0.75,
            zorder=5,
        )

    pure_x = [point["payoff"][0] for point in pure_points]
    pure_y = [point["payoff"][1] for point in pure_points]
    ax.scatter(
        pure_x,
        pure_y,
        s=90,
        marker="D",
        color="black",
        zorder=6,
    )
    for point in pure_points:
        x, y = point["payoff"]
        ax.annotate(
            point["label"],
            xy=(x, y),
            xytext=(8, 8),
            textcoords="offset points",
            fontsize=11,
            color="black",
        )

    d_a, d_b = status_quo
    ax.scatter(
        [d_a],
        [d_b],
        s=170,
        marker="s",
        color="darkorange",
        label="Status quo (гарантированные выигрыши)",
        zorder=7,
    )

    n_a, n_b = nash_payoff
    ax.scatter(
        [n_a],
        [n_b],
        s=220,
        marker="X",
        color="tab:green",
        label="Арбитражное решение Нэша",
        zorder=8,
    )
    ax.annotate(
        f"Нэш: ($u_A$, $u_B$)=({n_a:.3f}, {n_b:.3f})\nПроизведение={nash_product:.3f}",
        xy=(n_a, n_b),
        xytext=(14, -10),
        textcoords="offset points",
        fontsize=11,
        bbox={"boxstyle": "round,pad=0.3", "facecolor": "lightskyblue", "alpha": 0.85},
        zorder=9,
    )

    ax.set_title("Множество Парето, достижимые выплаты, status quo и арбитраж Нэша", fontsize=16)
    ax.set_xlabel(r"$u_A(p, q)$ — выигрыш игрока A", fontsize=13)
    ax.set_ylabel(r"$u_B(p, q)$ — выигрыш игрока B", fontsize=13)
    ax.grid(True, alpha=0.45)
    ax.legend(loc="best", fontsize=11)

    all_x = [point[0] for point in attainable_points] + [point["payoff"][0] for point in pure_points] + [d_a, n_a]
    all_y = [point[1] for point in attainable_points] + [point["payoff"][1] for point in pure_points] + [d_b, n_b]
    if all_x and all_y:
        min_x, max_x = min(all_x), max(all_x)
        min_y, max_y = min(all_y), max(all_y)
        pad_x = max(0.15, 0.06 * (max_x - min_x if max_x > min_x else 1.0))
        pad_y = max(0.15, 0.06 * (max_y - min_y if max_y > min_y else 1.0))
        ax.set_xlim(min_x - pad_x, max_x + pad_x)
        ax.set_ylim(min_y - pad_y, max_y + pad_y)

    fig.tight_layout()
    fig.savefig(output_path, dpi=160, bbox_inches="tight")

    try:
        if show_window:
            plt.show()
    finally:
        plt.close(fig)

    return output_path


# ------------------------------------------------------------
# МИНИМАЛЬНЫЙ ТЕКСТОВЫЙ ВЫВОД
# ------------------------------------------------------------
def _print_pareto_block(result: Dict[str, object]) -> None:
    archive = result["pareto_archive"]
    payoffs = result["pareto_payoffs"]
    strategies = result["pareto_strategies"]

    print("1) МНОЖЕСТВО ПАРЕТО-ОПТИМАЛЬНЫХ РЕШЕНИЙ")
    print(f"   Число решений в архиве: {len(archive)}")

    preview_count = min(10, len(archive))
    for i in range(preview_count):
        strategy_a, strategy_b = strategies[i]
        u_a, u_b = payoffs[i]
        print(f"   Решение #{i + 1}")
        print(f"     p = {st1.format_probability_vector(strategy_a)}")
        print(f"     q = {st1.format_probability_vector(strategy_b)}")
        print(f"     (u_A, u_B) = ({u_a:.6f}, {u_b:.6f})")



def _print_status_quo_block(result: Dict[str, object]) -> None:
    result_a = result["player_a"]
    result_b = result["player_b"]
    d_a, d_b = result["status_quo"]

    print("2) ТОЧКА STATUS QUO")
    print(f"   Игрок A: p* = {st1.format_probability_vector(result_a['strategy_a'])}")
    print(f"   d_A = {d_a:.6f}")
    print(f"   Игрок B: q* = {st1.format_probability_vector(result_b['strategy_b'])}")
    print(f"   d_B = {d_b:.6f}")
    print(f"   status quo = ({d_a:.6f}, {d_b:.6f})")



def _print_nash_block(result: Dict[str, object], pareto_best_for_nash: Dict[str, object] | None) -> None:
    u_a, u_b = result["payoff_pair"]

    print("3) КООПЕРАТИВНОЕ РЕШЕНИЕ ПО АРБИТРАЖНОЙ СХЕМЕ НЭША")
    print(f"   p = {st1.format_probability_vector(result['strategy_a'])}")
    print(f"   q = {st1.format_probability_vector(result['strategy_b'])}")
    print(f"   (u_A, u_B) = ({u_a:.6f}, {u_b:.6f})")
    print(f"   Произведение Нэша = {result['nash_product']:.6f}")

    if pareto_best_for_nash is not None:
        p_u_a, p_u_b = pareto_best_for_nash["payoff_pair"]
        print("   Лучшая точка архива Парето по произведению Нэша:")
        print(f"     p = {st1.format_probability_vector(pareto_best_for_nash['strategy_a'])}")
        print(f"     q = {st1.format_probability_vector(pareto_best_for_nash['strategy_b'])}")
        print(f"     (u_A, u_B) = ({p_u_a:.6f}, {p_u_b:.6f})")
        print(f"     Произведение Нэша = {pareto_best_for_nash['nash_product']:.6f}")


if __name__ == "__main__":
    result = solve_bimatrix_game()
    plot_data = build_visualization_data(result)

    _print_pareto_block(result["pareto"])
    print()
    _print_status_quo_block(result["status_quo"])
    print()
    _print_nash_block(result["nash"], result["pareto_best_for_nash"])
    print()

    output_file = plot_bimatrix_summary(plot_data)
    print(f"График сохранён в файл: {output_file}")
