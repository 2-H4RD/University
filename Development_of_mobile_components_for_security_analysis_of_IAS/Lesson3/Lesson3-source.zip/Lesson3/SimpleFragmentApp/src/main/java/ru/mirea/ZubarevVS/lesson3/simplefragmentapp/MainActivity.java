package ru.mirea.ZubarevVS.lesson3.simplefragmentapp;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
/** Один фрагмент в portrait, два независимых фрагмента в landscape. */
public class MainActivity extends AppCompatActivity {
    private static final String FIRST = "first";
    private static final String SECOND = "second";
    private String selected = FIRST; // Запоминаем выбранный портретный экран.
    private boolean twoPane;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Родитель восстанавливает состояние Activity.
        EdgeToEdge.enable(this); // Поддерживаем системное оформление Android 15.
        setContentView(R.layout.activity_main); // Сначала создаём View из XML.
        ScreenInsets.apply(findViewById(R.id.main)); // Убираем пересечение с панелями и клавиатурой.
        twoPane = findViewById(R.id.secondContainer) != null; // Признак XML из layout-land.
        if (savedInstanceState != null) selected = savedInstanceState.getString("selected", FIRST);
        FragmentManager manager = getSupportFragmentManager();
        // При смене ориентации контейнеры различаются. Удаляем восстановленные экземпляры
        // и переносим их сохранённое состояние в соответствующую новую раскладку.
        Fragment oldFirst = manager.findFragmentByTag(FIRST);
        Fragment oldSecond = manager.findFragmentByTag(SECOND);
        Fragment.SavedState firstState = oldFirst == null ? null : manager.saveFragmentInstanceState(oldFirst);
        Fragment.SavedState secondState = oldSecond == null ? null : manager.saveFragmentInstanceState(oldSecond);
        androidx.fragment.app.FragmentTransaction remove = manager.beginTransaction();
        for (Fragment fragment : manager.getFragments()) remove.remove(fragment);
        remove.commitNow(); // Сначала освобождаем контейнеры, затем добавляем нужные экраны.
        Fragment first = new FirstFragment();
        Fragment second = new SecondFragment();
        first.setInitialSavedState(firstState); // Ввод EditText сохраняется при смене ориентации.
        second.setInitialSavedState(secondState);
        if (twoPane) {
            manager.beginTransaction().setReorderingAllowed(true)
                    .add(R.id.fragmentContainerView, first, FIRST)
                    .add(R.id.secondContainer, second, SECOND).commitNow();
        } else {
            manager.beginTransaction().setReorderingAllowed(true)
                    .add(R.id.fragmentContainerView, FIRST.equals(selected) ? first : second, selected).commitNow();
            findViewById(R.id.btnFirstFragment).setOnClickListener(view -> show(FIRST));
            findViewById(R.id.btnSecondFragment).setOnClickListener(view -> show(SECOND));
        }
    }
    private void show(String tag) {
        if (tag.equals(selected)) return; // Повторное нажатие не сбрасывает текущий ввод.
        selected = tag;
        Fragment fragment = FIRST.equals(tag) ? new FirstFragment() : new SecondFragment();
        getSupportFragmentManager().beginTransaction().setReorderingAllowed(true)
                .replace(R.id.fragmentContainerView, fragment, tag).commit(); // Замена из методички.
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putString("selected", selected);
        super.onSaveInstanceState(outState); // FragmentManager сохраняет состояние активных фрагментов.
    }
}
