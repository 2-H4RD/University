package ru.mirea.ZubarevVS.lesson3.intentapp;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Задание 1.5: передаём фактическое время в отдельную Activity. */
public class MainActivity extends AppCompatActivity {
    static final String TIME_KEY = "sent_time"; // Одинаковый ключ используется обоими экранами.
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Родитель восстанавливает состояние Activity.
        EdgeToEdge.enable(this); // Поддерживаем системное оформление Android 15.
        setContentView(R.layout.activity_main); // Сначала создаём View из XML.
        ScreenInsets.apply(findViewById(R.id.main)); // Убираем пересечение с панелями и клавиатурой.
        if (savedInstanceState != null) {
            ((TextView) findViewById(R.id.time)).setText(savedInstanceState.getString(TIME_KEY));
        }
        findViewById(R.id.send).setOnClickListener(view -> {
            long dateInMillis = System.currentTimeMillis(); // Время компьютера/телефона в миллисекундах.
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String dateString = sdf.format(new Date(dateInMillis)); // Форматируем дату и время из задания.
            ((TextView) findViewById(R.id.time)).setText(getString(R.string.time_value, dateString));
            Intent intent = new Intent(this, SecondActivity.class); // Явно указываем получателя.
            intent.putExtra(TIME_KEY, dateString); // Extra передаёт строку, а не заново вычисленное время.
            startActivity(intent); // Android открывает второй экран.
        });
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putString(TIME_KEY, ((TextView) findViewById(R.id.time)).getText().toString());
        super.onSaveInstanceState(outState); // Последняя отправка остаётся видна после поворота.
    }
}
