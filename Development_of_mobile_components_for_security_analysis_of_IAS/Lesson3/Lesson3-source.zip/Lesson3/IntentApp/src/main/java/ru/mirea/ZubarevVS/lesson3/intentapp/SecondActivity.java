package ru.mirea.ZubarevVS.lesson3.intentapp;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;
/** Внутренняя Activity читает переданное время и показывает квадрат номера 5. */
public class SecondActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second); // Здесь нужен макет именно второго экрана.
        ScreenInsets.apply(findViewById(R.id.main));
        String time = getIntent().getStringExtra(MainActivity.TIME_KEY); // Ключ должен совпасть с putExtra.
        TextView result = findViewById(R.id.result);
        result.setText(time == null ? getString(R.string.missing) : getString(R.string.result, time));
        findViewById(R.id.back).setOnClickListener(view -> finish()); // Закрываем текущий экран, возвращаясь к первому.
    }
}
