package ru.mirea.ZubarevVS.lesson3.favoritebook;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;
import android.app.Activity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

/** Задание 1.7: явный Intent туда, Activity Result API обратно. */
public class MainActivity extends AppCompatActivity {
    static final String BOOK_NAME_KEY = "book_name";
    static final String QUOTES_KEY = "quotes_name"; // Строковые константы предотвращают несовпадение ключей.
    static final String USER_MESSAGE = "MESSAGE";
    private final ActivityResultLauncher<Intent> launcher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    String message = result.getData().getStringExtra(USER_MESSAGE); // Ответ подготовлен ShareActivity.
                    if (message != null) ((TextView) findViewById(R.id.textViewBook)).setText(message);
                } // При Back/Отмене оставляем предыдущий результат.
            });
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Родитель восстанавливает состояние Activity.
        EdgeToEdge.enable(this); // Поддерживаем системное оформление Android 15.
        setContentView(R.layout.activity_main); // Сначала создаём View из XML.
        ScreenInsets.apply(findViewById(R.id.main)); // Убираем пересечение с панелями и клавиатурой.
        if (savedInstanceState != null) {
            ((TextView) findViewById(R.id.textViewBook)).setText(savedInstanceState.getString(USER_MESSAGE));
        }
        findViewById(R.id.open).setOnClickListener(this::getInfoAboutBook);
    }
    public void getInfoAboutBook(View view) {
        Intent intent = new Intent(this, ShareActivity.class); // Внутренний экран не требуется выбирать через chooser.
        intent.putExtra(BOOK_NAME_KEY, getString(R.string.developer_book)); // Личные данные хранятся в ресурсах.
        intent.putExtra(QUOTES_KEY, getString(R.string.developer_quote));
        launcher.launch(intent); // Ждём результат, а не просто запускаем Activity.
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putString(USER_MESSAGE, ((TextView) findViewById(R.id.textViewBook)).getText().toString());
        super.onSaveInstanceState(outState); // Не теряем полученную книгу после поворота.
    }
}
