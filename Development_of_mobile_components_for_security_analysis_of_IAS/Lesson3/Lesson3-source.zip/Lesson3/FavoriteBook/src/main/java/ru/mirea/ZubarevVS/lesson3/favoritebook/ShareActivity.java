package ru.mirea.ZubarevVS.lesson3.favoritebook;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;
import android.app.Activity;
import android.widget.EditText;
/** Показывает книгу разработчика и возвращает введённую книгу пользователя. */
public class ShareActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_share);
        ScreenInsets.apply(findViewById(R.id.main));
        String book = getIntent().getStringExtra(MainActivity.BOOK_NAME_KEY);
        String quote = getIntent().getStringExtra(MainActivity.QUOTES_KEY);
        ((TextView) findViewById(R.id.developer_book)).setText(book == null ? getString(R.string.developer_book) : book);
        ((TextView) findViewById(R.id.developer_quote)).setText(quote == null ? getString(R.string.developer_quote) : quote);
        findViewById(R.id.send).setOnClickListener(view -> {
            EditText bookInput = findViewById(R.id.book_name);
            EditText quoteInput = findViewById(R.id.quote);
            String userBook = bookInput.getText().toString().trim();
            String userQuote = quoteInput.getText().toString().trim();
            if (userBook.isEmpty()) { bookInput.setError(getString(R.string.required)); return; }
            if (userQuote.isEmpty()) { quoteInput.setError(getString(R.string.required)); return; }
            Intent data = new Intent(); // Для возвращаемых данных адрес Activity не нужен.
            data.putExtra(MainActivity.USER_MESSAGE, getString(R.string.result, userBook, userQuote));
            setResult(Activity.RESULT_OK, data); // RESULT_OK равен -1; 1 не является кодом успеха.
            finish(); // Передаём управление и результат обратно родительскому экрану.
        });
        findViewById(R.id.cancel).setOnClickListener(view -> {
            setResult(Activity.RESULT_CANCELED); // Отмена не затирает ранее полученную книгу.
            finish();
        });
    }
}
