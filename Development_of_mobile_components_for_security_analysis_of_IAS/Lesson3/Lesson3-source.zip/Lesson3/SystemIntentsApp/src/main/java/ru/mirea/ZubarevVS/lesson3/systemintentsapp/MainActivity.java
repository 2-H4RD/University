package ru.mirea.ZubarevVS.lesson3.systemintentsapp;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;
import android.content.ActivityNotFoundException;
import android.net.Uri;
/** Задание 1.9: три кнопки с обработчиками setOnClickListener. */
public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Родитель восстанавливает состояние Activity.
        EdgeToEdge.enable(this); // Поддерживаем системное оформление Android 15.
        setContentView(R.layout.activity_main); // Сначала создаём View из XML.
        ScreenInsets.apply(findViewById(R.id.main)); // Убираем пересечение с панелями и клавиатурой.
        if (savedInstanceState != null) ((TextView) findViewById(R.id.status)).setText(savedInstanceState.getString("status"));
        findViewById(R.id.call).setOnClickListener(this::onClickCall); // Назначаем слушатель в коде.
        findViewById(R.id.browser).setOnClickListener(this::onClickOpenBrowser);
        findViewById(R.id.maps).setOnClickListener(this::onClickOpenMaps);
    }
    public void onClickCall(View view) {
        open(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:89811112233"))); // Открываем экран набора номера.
    }
    public void onClickOpenBrowser(View view) {
        open(new Intent(Intent.ACTION_VIEW, Uri.parse("https://developer.android.com")));
    }
    public void onClickOpenMaps(View view) {
        open(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:55.749479,37.613944"))); // Карта с координатами из задания.
    }
    private void open(Intent intent) {
        TextView status = findViewById(R.id.status);
        try {
            startActivity(intent); // Запускаем напрямую и обрабатываем отсутствие получателя.
            status.setText(getString(R.string.status, intent.getAction(), intent.getDataString()));
        } catch (ActivityNotFoundException exception) {
            status.setText(getString(R.string.no_app, intent.getDataString())); // Например, Maps может не быть в образе.
        }
    }
    @Override protected void onSaveInstanceState(Bundle outState) {
        outState.putString("status", ((TextView) findViewById(R.id.status)).getText().toString());
        super.onSaveInstanceState(outState);
    }
}
