package ru.mirea.ZubarevVS.mireaproject;

import android.app.Application;
import com.google.android.material.color.DynamicColors;
/** Material You: на Android 12+ используем палитру текущих обоев. */
public class MireaApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        DynamicColors.applyToActivitiesIfAvailable(this); // На старых версиях остаются цвета из themes.xml.
    }
}
