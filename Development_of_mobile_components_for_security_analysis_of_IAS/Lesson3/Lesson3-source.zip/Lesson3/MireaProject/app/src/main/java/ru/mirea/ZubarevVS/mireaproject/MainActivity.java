package ru.mirea.ZubarevVS.mireaproject;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;
import androidx.core.view.GravityCompat;
import androidx.activity.OnBackPressedCallback;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import ru.mirea.ZubarevVS.mireaproject.databinding.ActivityMainBinding;
/** Структура Navigation Drawer Activity: Toolbar, DrawerLayout, NavHost и граф. */
public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    private NavController navController;
    private AppBarConfiguration appBarConfiguration;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater()); // Имя Binding получено из activity_main.xml.
        setContentView(binding.getRoot());
        ScreenInsets.apply(binding.appBarMain.getRoot());
        View header = binding.navView.getHeaderView(0); // У шторки собственный header вне основного экрана.
        int headerLeft = header.getPaddingLeft();
        int headerTop = header.getPaddingTop();
        int headerRight = header.getPaddingRight();
        int headerBottom = header.getPaddingBottom();
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(binding.drawerLayout, (view, insets) -> {
            int statusTop = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.statusBars()).top;
            header.setPadding(headerLeft, headerTop + statusTop, headerRight, headerBottom); // Заголовок drawer ниже статус-бара.
            return insets;
        });
        androidx.core.view.ViewCompat.requestApplyInsets(binding.drawerLayout);
        setSupportActionBar(binding.appBarMain.toolbar); // Toolbar становится ActionBar.
        NavHostFragment host = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main);
        navController = host.getNavController(); // Берём контроллер у NavHost, как рекомендовано в задании.
        appBarConfiguration = new AppBarConfiguration.Builder(R.id.nav_data, R.id.nav_web)
                .setOpenableLayout(binding.drawerLayout).build(); // Оба экрана — верхний уровень с «гамбургером».
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(binding.navView, navController); // Одинаковые ID связывают меню и граф.
        OnBackPressedCallback drawerBack = new OnBackPressedCallback(false) {
            @Override public void handleOnBackPressed() { binding.drawerLayout.closeDrawer(GravityCompat.START); }
        };
        getOnBackPressedDispatcher().addCallback(this, drawerBack);
        binding.drawerLayout.addDrawerListener(new androidx.drawerlayout.widget.DrawerLayout.SimpleDrawerListener() {
            @Override public void onDrawerOpened(View drawerView) { drawerBack.setEnabled(true); }
            @Override public void onDrawerClosed(View drawerView) { drawerBack.setEnabled(false); }
        }); // Back сначала закрывает открытую шторку.
    }
    @Override public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(navController, appBarConfiguration) || super.onSupportNavigateUp();
    }
}

