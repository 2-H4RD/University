package ru.mirea.ZubarevVS.mireaproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import ru.mirea.ZubarevVS.mireaproject.databinding.FragmentDataBinding;
/** Информационный экран отрасли; Binding живёт только пока существует View фрагмента. */
public class DataFragment extends Fragment {
    private FragmentDataBinding binding;
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        binding = FragmentDataBinding.inflate(inflater, container, false); // Создаём XML через сгенерированный класс.
        return binding.getRoot();
    }
    @Override public void onDestroyView() {
        super.onDestroyView();
        binding = null; // Не удерживаем старую View после перехода на другой экран.
    }
}
