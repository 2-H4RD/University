// Общая версия Android Gradle Plugin взята из Lesson2.
plugins { alias(libs.plugins.android.application) apply false }
