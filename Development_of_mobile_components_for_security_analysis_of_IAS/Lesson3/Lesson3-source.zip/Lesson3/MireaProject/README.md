# MireaProject — контрольное задание практики №3

Самостоятельный Android Studio проект на Java/XML Views. Открывайте **эту папку**, содержащую `settings.gradle.kts`, отдельно от родительского Lesson3. Конфигурация запуска: **app**.

- **DataFragment:** информация о кибербезопасности, три карточки практических задач, NestedScrollView.
- **WebViewFragment:** HTTPS-браузер со страницей МИРЭА, полем адреса, историей и индикатором загрузки.
- **Navigation Drawer:** DrawerLayout, Toolbar, NavigationView, NavHostFragment и граф `res/navigation/mobile_navigation.xml`.
- **View Binding:** включён в app/build.gradle.kts; ссылки на View через сгенерированные Binding-классы.
- **Material You:** тема Material 3, отступы, скругления и DynamicColors на Android 12+.

Студент: Зубарев Василий Сергеевич, БИСО-02-22, №5.

Для сборки используйте встроенный JDK Android Studio и выполните `gradlew.bat assembleDebug lintDebug`. APK: `app/build/outputs/apk/debug/app-debug.apk`.

Подробная инструкция защиты находится в родительской папке Lesson3: разделы 9–10. Фактические результаты проверки — `../verification/REPORT.md`.
