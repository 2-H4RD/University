// Репозитории доступны всем application-модулям этого проекта.
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "Lesson3"
include(":IntentApp", ":Sharer", ":FavoriteBook", ":SystemIntentsApp", ":SimpleFragmentApp")
