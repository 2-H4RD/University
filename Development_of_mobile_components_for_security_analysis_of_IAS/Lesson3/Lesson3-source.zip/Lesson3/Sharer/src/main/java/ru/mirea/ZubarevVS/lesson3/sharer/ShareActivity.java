package ru.mirea.ZubarevVS.lesson3.sharer;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;
/** Экспортируемый получатель текста из системного окна «Поделиться». */
public class ShareActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_share);
        ScreenInsets.apply(findViewById(R.id.main));
        Intent intent = getIntent(); // Данные пришли от другого приложения и могут быть пустыми.
        CharSequence message = Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())
                ? intent.getCharSequenceExtra(Intent.EXTRA_TEXT) : null;
        ((TextView) findViewById(R.id.received)).setText(message == null ? getString(R.string.receive_empty) : message);
        findViewById(R.id.back).setOnClickListener(view -> finish());
    }
}
